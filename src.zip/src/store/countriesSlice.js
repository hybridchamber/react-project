
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

export const fetchCountries = createAsyncThunk(
  'countries/fetchAll',
  async (_, { rejectWithValue }) => {
    try {
      const res = await fetch(
        'https://restcountries.com/v2/all?fields=name,region,flag'
      );
      if (!res.ok) throw new Error('Failed to fetch');
      return await res.json();
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

const countriesSlice = createSlice({
  name: 'countries',
  initialState: {
    all: [],
    filtered: [],
    selectedRegion: 'All',
    loading: false,
    error: null,
    page: 1,
    pageSize: 12,
  },
  reducers: {
    setRegion(state, action) {
      state.selectedRegion = action.payload;
      state.page = 1;
      state.filtered =
        action.payload === 'All'
          ? state.all
          : state.all.filter((c) => c.region === action.payload);
    },
    loadMore(state) {
      state.page += 1;
    },
    resetPage(state) {
      state.page = 1;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchCountries.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCountries.fulfilled, (state, action) => {
        state.loading = false;
        state.all = action.payload;
        state.filtered = action.payload;
      })
      .addCase(fetchCountries.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { setRegion, loadMore, resetPage } = countriesSlice.actions;
export default countriesSlice.reducer;