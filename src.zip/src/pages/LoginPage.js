
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Form, Button, InputGroup } from 'react-bootstrap';
import { login } from '../store/authSlice';
import './LoginPage.css';

const slides = [
  {
    title: 'Explore the World',
    subtitle: 'Discover countries, cultures, and regions across the globe.',
    bg: 'linear-gradient(135deg, #1a2a4a 0%, #2b3a55 60%, #e8a838 100%)',
  },
  {
    title: 'Rich Data at a Glance',
    subtitle: 'Flags, regions, and details for every country on Earth.',
    bg: 'linear-gradient(135deg, #1a3a2a 0%, #2b5540 60%, #38a169 100%)',
  },
  {
    title: 'Filter by Continent',
    subtitle: 'Quickly navigate continents and find the info you need.',
    bg: 'linear-gradient(135deg, #3a1a2a 0%, #552b40 60%, #e84838 100%)',
  },
];

const validatePassword = (pw) => {
  if (pw.length < 8) return 'Password must be at least 8 characters.';
  if (!/[A-Z]/.test(pw)) return 'Must contain at least 1 capital letter.';
  if (!/[0-9]/.test(pw)) return 'Must contain at least 1 number.';
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(pw))
    return 'Must contain at least 1 symbol.';
  return '';
};

export default function LoginPage() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [showPw, setShowPw] = useState(false);
  const [slide, setSlide] = useState(0);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => ({ ...f, [name]: value }));
    setErrors((er) => ({ ...er, [name]: '' }));
  };

  const validate = () => {
    const errs = {};
    if (!form.email) {
      errs.email = 'Email is required.';
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      errs.email = 'Enter a valid email address.';
    }
    const pwErr = validatePassword(form.password);
    if (pwErr) errs.password = pwErr;
    return errs;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    dispatch(login({ email: form.email }));
    navigate('/home');
  };

  const prevSlide = () =>
    setSlide((s) => (s - 1 + slides.length) % slides.length);
  const nextSlide = () =>
    setSlide((s) => (s + 1) % slides.length);

  return (
    <div className="login-root">
      {/* Left — Slider */}
      <div className="login-slider" style={{ background: slides[slide].bg }}>
        <div className="slider-content">
          <div className="slider-globe"></div>
          <h2 className="slider-title">{slides[slide].title}</h2>
          <p className="slider-subtitle">{slides[slide].subtitle}</p>
        </div>
        <div className="slider-controls">
          <button className="slider-btn" onClick={prevSlide}>‹</button>
          <div className="slider-dots">
            {slides.map((_, i) => (
              <button
                key={i}
                className={`dot ${i === slide ? 'active' : ''}`}
                onClick={() => setSlide(i)}
              />
            ))}
          </div>
          <button className="slider-btn" onClick={nextSlide}>›</button>
        </div>
      </div>

      {/* Right — Form */}
      <div className="login-form-side">
        <div className="login-card">
          <div className="login-logo"></div>
          <h1 className="login-heading">Welcome Back</h1>
          <p className="login-sub">Sign in to explore the world's countries</p>

          <Form onSubmit={handleSubmit} noValidate>
            <Form.Group className="mb-3" controlId="email">
              <Form.Label className="login-label">Email Address</Form.Label>
              <Form.Control
                type="email"
                name="email"
                placeholder="you@example.com"
                value={form.email}
                onChange={handleChange}
                isInvalid={!!errors.email}
                className="login-input"
              />
              <Form.Control.Feedback type="invalid">
                {errors.email}
              </Form.Control.Feedback>
            </Form.Group>

            <Form.Group className="mb-1" controlId="password">
              <Form.Label className="login-label">Password</Form.Label>
              <InputGroup>
                <Form.Control
                  type={showPw ? 'text' : 'password'}
                  name="password"
                  placeholder="Min 8 chars, 1 Cap, 1 number, 1 symbol"
                  value={form.password}
                  onChange={handleChange}
                  isInvalid={!!errors.password}
                  className="login-input"
                />
                <Button
                  variant="outline-secondary"
                  className="pw-toggle"
                  onClick={() => setShowPw((v) => !v)}
                  tabIndex={-1}
                >
                  {showPw ? '' : ''}
                </Button>
                <Form.Control.Feedback type="invalid">
                  {errors.password}
                </Form.Control.Feedback>
              </InputGroup>
            </Form.Group>

            {/* Live password hints */}
            <div className="pw-hints">
              <span className={form.password.length >= 8 ? 'hint ok' : 'hint'}>
                ✔ 8+ chars
              </span>
              <span className={/[A-Z]/.test(form.password) ? 'hint ok' : 'hint'}>
                ✔ Capital
              </span>
              <span className={/[0-9]/.test(form.password) ? 'hint ok' : 'hint'}>
                ✔ Number
              </span>
              <span
                className={
                  /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(form.password)
                    ? 'hint ok'
                    : 'hint'
                }
              >
                ✔ Symbol
              </span>
            </div>

            <Button type="submit" className="login-btn w-100 mt-3">
              Sign In
            </Button>
          </Form>
        </div>
      </div>
    </div>
  );
}