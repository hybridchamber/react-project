import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Container, Row, Col, Button, Spinner } from 'react-bootstrap';
import { fetchCountries, setRegion, loadMore } from '../store/countriesSlice';
import { logout } from '../store/authSlice';
import CountryCard from '../components/CountryCard';
import './HomePage.css';

const REGIONS = ['All', 'Africa', 'Americas', 'Asia', 'Europe', 'Oceania'];

export default function HomePage() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { filtered, selectedRegion, loading, error, page, pageSize } =
    useSelector((state) => state.countries);
  const user = useSelector((state) => state.auth.user);

  useEffect(() => {
    dispatch(fetchCountries());
  }, [dispatch]);

  const handleLogout = () => {
    dispatch(logout());
    navigate('/');
  };

  const visibleCountries = filtered.slice(0, page * pageSize);
  const hasMore = visibleCountries.length < filtered.length;

  return (
    <div className="home-root">
      {/* Navbar */}
      <nav className="home-nav">
        <div className="nav-brand">
          <span className="nav-globe"></span>
          <span className="nav-title">WorldExplorer</span>
        </div>
        <div className="nav-right">
          <span className="nav-user">👤 {user?.email}</span>
          <Button
            variant="outline-light"
            size="sm"
            className="logout-btn"
            onClick={handleLogout}
          >
            Logout
          </Button>
        </div>
      </nav>

      <Container fluid className="home-container">
        {/* Page Header */}
        <div className="home-header">
          <h1 className="home-heading">Countries of the World</h1>
          <p className="home-sub">
            {filtered.length} countries
            {selectedRegion !== 'All' && ` in ${selectedRegion}`}
          </p>
        </div>

        {/* Region Filter Buttons */}
        <div className="region-filters">
          {REGIONS.map((r) => (
            <button
              key={r}
              className={`region-btn ${selectedRegion === r ? 'active' : ''}`}
              onClick={() => dispatch(setRegion(r))}
            >
              {r}
            </button>
          ))}
        </div>

        {/* Loading Spinner */}
        {loading && (
          <div className="center-state">
            <Spinner animation="border" style={{ color: '#2b3a55' }} />
            <p className="mt-3">Loading countries…</p>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="center-state">
            <p className="text-danger">⚠️ {error}</p>
            <Button onClick={() => dispatch(fetchCountries())} className="mt-2">
              Retry
            </Button>
          </div>
        )}

        {/* Countries Grid */}
        {!loading && !error && (
          <>
            <Row className="g-4 mt-1">
              {visibleCountries.map((country, idx) => (
                <Col
                  key={`${country.name}-${idx}`}
                  xs={12} sm={6} md={4} lg={3}
                >
                  <CountryCard country={country} />
                </Col>
              ))}
            </Row>

            {visibleCountries.length === 0 && (
              <div className="center-state">
                <p>No countries found for this region.</p>
              </div>
            )}

            {/* Load More Button */}
            {hasMore && (
              <div className="load-more-wrap">
                <Button
                  className="load-more-btn"
                  onClick={() => dispatch(loadMore())}
                >
                  Load More
                  <span className="load-more-count">
                    {filtered.length - visibleCountries.length} remaining
                  </span>
                </Button>
              </div>
            )}

            {!hasMore && visibleCountries.length > 0 && (
              <p className="all-loaded">
                All {filtered.length} countries loaded
              </p>
            )}
          </>
        )}
      </Container>
    </div>
  );
}