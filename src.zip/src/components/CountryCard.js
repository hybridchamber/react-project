

import React from 'react';
import './CountryCard.css';

const REGION_COLORS = {
  Africa:   '#e8a838',
  Americas: '#38a169',
  Asia:     '#e84838',
  Europe:   '#3b82f6',
  Oceania:  '#8b5cf6',
  '':       '#6b7a99',
};

export default function CountryCard({ country }) {
  const { name, flag, region } = country;
  const color = REGION_COLORS[region] || REGION_COLORS[''];

  return (
    <div className="country-card">
      <div className="card-flag-wrap">
        <img
          src={flag}
          alt={`Flag of ${name}`}
          className="card-flag"
          loading="lazy"
        />
      </div>
      <div className="card-body-inner">
        <h3 className="card-name">{name}</h3>
        <span
          className="card-region"
          style={{ background: color + '22', color }}
        >
          {region || 'Unknown'}
        </span>
      </div>
    </div>
  );
}